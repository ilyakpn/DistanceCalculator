package ru.test.distancecalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistanceCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
